const express= require('express')
const mongoose=require('mongoose');
const app= express();
const {MONGOURL}=require('./keys');
const cors =require('cors')

mongoose.connect(MONGOURL,{
    useNewUrlParser:true,
    useUnifiedTopology:true
})
mongoose.connection.on('connected',()=>{
    console.log("connected to mongoose");
})
mongoose.connection.on('error',(err)=>{
    console.log("connected to mongoose",err);
})
require('./models/user')
require('./models/post')

const rout=require('./routes/auth')
const postRout=require('./routes/post')

app.use(express.json())
app.use(cors())
app.use(rout);
app.use(postRout);


app.listen(5000,()=>{
    console.log("app is running in port 5000");
})