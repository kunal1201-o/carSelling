module.exports={
    MONGOURL:"mongodb+srv://Kunalsingh:fVvAXFUxjRL8x82K@cluster0.a8k7wmg.mongodb.net/test",
    jwt_scret:"sojfiewufkjs"
}