const express=require('express');
const routes= express.Router();
const mongoose=require('mongoose');
const User= mongoose.model("User");
const bcrypt=require('bcryptjs');
const jwt=require('jsonwebtoken');
const{jwt_scret}=require('../keys')
const requiredlog=require('../middleware/requireLogin')


routes.get('/protected',requiredlog,(req,res)=>{
    res.send("Hello World");
})

routes.post('/signup',(req,res)=>{
    const{name,email,password}=req.body;

    if(!email || !name ||!password){
      return res.status(404).json({error:"field is empty"});
    }
    User.findOne({email:email})
    .then((savedFile)=>{
        if(savedFile){
            return res.status(404).json({error:"USer already exit"});
        }
        bcrypt.hash(password,12)
        .then(hashPassword=>{
            const user= new User({
                email,
                name,
                password:hashPassword
            })
            user.save()
            .then(user=>{
               res.json({message:"successfully registered"});
            }).catch(err=>{
                console.log(err);
            })
        })
        
    }).catch(err=>{
        console.log(err);
    })
})

routes.post('/signin',(req,res)=>{
    const{email,password}=req.body;

    if(!email ||!password){
        return res.status(404).json({error:"Provide the email and password"});
    }

User.findOne({email:email})
.then((savedUser)=>{
    if(!savedUser){
        return res.status(404).json({error:"Invalid email and password"});
    }
    bcrypt.compare(password,savedUser.password)
    .then(domatch=>{
        if(domatch){
            const token = jwt.sign({_id:savedUser._id},jwt_scret)
           const {_id,name,email}=savedUser
            res.json({token,user:{_id,name,email}});
        }else{
            return res.status(404).json({error:"Invalid email and password"});
        }

    }).catch(err=>{
        console.log(err);
    })
}).catch(err=>{
    console.log(err);
})

})
module.exports = routes;