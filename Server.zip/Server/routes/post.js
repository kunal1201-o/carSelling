const express = require('express');
const routes = express.Router();
const mongoose = require('mongoose');
const requireLogin = require('../middleware/requireLogin');
const Post = mongoose.model('Post')


routes.get('/allpost', (req, res) => {
    Post.find()
        .populate('postedby', '_id name email')
        .then(savepost => {
            res.json({ savepost })
        }).catch(err => {
            console.log(err);
        })
})


routes.post('/createPost', (req, res) => {
    const { name, email, mobile, address, subject, message } = req.body;
    if (!name || !email) {
        return res.status(404).json({ error: "Please enter the tille and body" })
    }
    // req.user.password=undefined;
    // req.user.__v=undefined;
    const post = new Post({
        name,
        email,
        mobile,
        address,
        subject,
        message,
        postedby: req.user

    })
    post.save()
        .then(savedPost => {
            res.json(
                {
                    post: savedPost,
                    message: 'Success'
                }
            );
        }).catch(err => {
            console.log(err);
        })
})

routes.get('/mypost', requireLogin, (req, res) => {
    Post.find({ postedby: req.user._id })
        .populate("postedby", "_id name email")
        .then(myposted => {
            res.json({ myposted })
        }).catch(err => { console.log(err) })
})
module.exports = routes;