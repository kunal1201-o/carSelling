
import './App.css';
import Navbar from './components/Navbar';
import { BrowserRouter, Route, Routes } from 'react-router-dom'
import Home from './components/screen/Home';
import Profile from './components/screen/Profile';
import Login from './components/screen/Login';
import Signup from './components/screen/Signup';
import CreatePost from './components/screen/CreatePost';
function App() {
  // let user = JSON.parse(localStorage.getItem('user')) ? JSON.parse(localStorage.getItem('user')) : {};
  // console.log(user);

  return (
    <>
      <BrowserRouter>

        <Navbar/>
        <Routes>
          <Route path="/" element={<Home />} ></Route>
          <Route path="/profile" element={<Profile />}></Route>
          <Route path="/signup" element={<Signup />}></Route>
          <Route path="/Login" element={<Login />}></Route>
          <Route path="/CreatePost" element={<CreatePost />}></Route>
        </Routes>
      </BrowserRouter>

    </>
  );
}
export default App;
