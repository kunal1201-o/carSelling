import React from 'react'
import { Link } from 'react-router-dom'
import '../App.css'
const Navbar = () => {
  return (
    <nav>
      <div className="nav-wrapper white px-4">
        <Link to="/" className="brand-logo left">Apni Car</Link>
        <ul id="nav-mobile" className="right ">

          {/* <li><Link to="/Login" onClick={signOut}>Sign Out</Link></li> */}
          <li><Link to="/Login">Login</Link></li>
          <li><Link to="/signup">Signup</Link></li>

          <li><Link to="/CreatePost">Contact us</Link></li>
        </ul>
      </div>
    </nav>

  )
}

export default Navbar