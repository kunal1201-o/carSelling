import React from 'react'
import './Home.css';
import './carousel.css';
import './carousel.rtl.css';
import home from '../../assets/Home.avif';
import bucati from '../../assets/Bugati.jpg'
import Safari from '../../assets/safari1.webp'
import Scorpio from '../../assets/Scorpio.webp'
import p from '../../assets/scorpioMen.webp'
import q from '../../assets/SafariMen.webp'
import r from '../../assets/BucatiMen.webp'
const Home = () => {
  return (
    <div id='Home'>
      {/* <header>
        <nav className="navbar navbar-expand-md navbar-dark fixed-top bg-dark">
          <div className="container-fluid">
            <a className="navbar-brand" to="#">Carousel</a>
            <button className="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarCollapse"
              aria-controls="navbarCollapse" aria-expanded="false" aria-label="Toggle navigation">
              <span className="navbar-toggler-icon"></span>
            </button>
            <div className="collapse navbar-collapse" id="navbarCollapse">
              <ul className="navbar-nav me-auto mb-2 mb-md-0">
                <li className="nav-item">
                  <a className="nav-link active" aria-current="page" to="#">Home</a>
                </li>
                <li className="nav-item">
                  <a className="nav-link" to="#">Link</a>
                </li>
                <li className="nav-item">
                  <a className="nav-link disabled">Disabled</a>
                </li>
              </ul>
              <form className="d-flex" role="search">
                <input className="form-control me-2" type="search" placeholder="Search" aria-label="Search"/>
                  <button className="btn btn-outline-success" type="submit">Search</button>
              </form>
            </div>
          </div>
        </nav>
      </header> */}

      <main>

        <div className="">
          <img src={home} id="HomeImage" alt="" srcset="" />
        </div>


        <div className="container marketing">
          <div className="row">
            <div className="col-lg-4">
             <img src={bucati} className="car-image" alt="" />

              <h2 className="fw-normal">Bucati</h2>
              <p>Bugatti Chiron review: 261mph, 1479bhp, £2.4m super sports car driven ... There is a moment driving the new Bugatti Chiron when you appreciate .</p>
             
            </div>
            <div className="col-lg-4">
            <img src={Safari} className="car-image" alt="" />

              <h2 className="fw-normal">Safari</h2>
              <p>Tata Safari is a 6 seater SUV available in a price range of ₹ 15.35 - 23.56 Lakh. It is available in 30 variants, 1956 cc engine option and 2 transmission
              </p>
              
            </div>
            <div className="col-lg-4">
            <img src={Scorpio} className="car-image" alt="" />

              <h2 className="fw-normal">Scorpio N</h2>
              <p>Mahindra Scorpio-N ... Mahindra Scorpio N is a 6 seater SUV available in a price range of ₹ 11.99 - 23.90 Lakh. It is available in 25 variants, 1997 to 2184 cc </p>
            
            </div>
          </div>


          <hr className="featurette-divider" />

          <div className="row m-0 p-0 featurette">
            <div className="col-md-7">
              <h2 className="featurette-heading fw-normal lh-1">Bugati <span className="text-muted">Review</span></h2>
              <p className="lead">The speed looking is too good the interior is awesome no car can be like bucati its so expensive even all people dream to buy this car but no because only the celebrates I love that I also dream of having this car my dream is too buy this car I will buy this car definitely by my hardworking bucati love u</p>
            </div>
            <div className="col-md-5">
            <img src={r} className="car" alt="" />

            </div>
          </div>

          <hr className="featurette-divider" />

          <div className="row m-0 p-0 featurette">
            <div className="col-md-7 order-md-2">
              <h2 className="featurette-heading fw-normal lh-1">Safari  <span className="text-muted">Review</span></h2>
              <p className="lead">I had driven it with my friends till Kanyakumari. The car is simply superb. Most suitable for long drives. The comfort that it offers for the driver and passengers is next level.</p>
            </div>
            <div className="col-md-5 order-md-1">
            <img src={q} className="car" alt="" />

            </div>
          </div>

          <hr className="featurette-divider" />

          <div className="row m-0 p-0 featurette">
            <div className="col-md-7">
              <h2 className="featurette-heading fw-normal lh-1">Scorpio <span className="text-muted">Review</span>
              </h2>
              <p className="lead">It's best in class car in terms of performance, maintenance, and road presence. The gear shifting, handling and torque performance are best at this price..</p>
            </div>
            <div className="col-md-5">
            <img src={p} className="car " alt="" />

            </div>
          </div>

          <hr className="featurette-divider" />

        </div>


        <footer className="container">
          <p className="float-end"><a to="#">Back to top</a></p>
          <p>&copy; 2017–2022 Company, Inc. &middot; <a to="#">Privacy</a> &middot; <a to="#">Terms</a></p>
        </footer>
      </main>
    </div>
  )
}

export default Home