import React,{useState} from 'react'
import { useNavigate } from 'react-router-dom'
import M from 'materialize-css'
const CreatePost = () => {
  const history=useNavigate();
  const [name,setName]=useState("");
  const [email,setEmail]=useState("");
  const [mobile,setMobile]= useState("")
  const [address,setAddress]=useState("");
  const [subject,setSubject]=useState("");
  const [message,setMessage]= useState("");

  const Contact=()=>{
    
    fetch("http://localhost:5000/createPost",{
      method:"post",
      headers:{
        "Content-Type":"application/json"
      },
      body:JSON.stringify({
        name,
        email,
        mobile,
        address,
        subject,
        message
      })
    }).then(res=>res.json())
    .then(data=>{
      console.log(data.message);
      if(data.error){
        M.toast({html: data.error ,classes:"#f44336 red"})
      }else{
        M.toast({html:"our team will contact you as soon as possible",classes:"#43a047 green darken-1"})
        history('/')
      }
    }).catch(err=>{
      console.log(err);
    })
  }
  return (
    <div className='card-holder'>
    <div class="card ">
    <p className="brand-logo">Instagram</p>
    <input type="text" placeholder='Name' value={name} onChange={(e)=>setName(e.target.value)}/>
     <input type="email" placeholder='Email' value={email} onChange={(e)=>setEmail(e.target.value)}/>
     <input type="text" placeholder='Mobile no' value={mobile} onChange={(e)=>setMobile(e.target.value)}/>
     <input type="text" placeholder='Address' value={address} onChange={(e)=>setAddress(e.target.value)}/>
     <input type="text" placeholder='Subject' value={subject} onChange={(e)=>setSubject(e.target.value)}/>
     <textarea type="message" placeholder='Message' value={message} onChange={(e)=>setMessage(e.target.value)}/>

  
     <button onClick={()=>Contact()}>Contact us</button>
    
</div>
</div>
    
  )
}

export default CreatePost