import React, {useState}from 'react'
import { Link,useNavigate } from 'react-router-dom'
import M from 'materialize-css'
const Signup = () => {
    const history=useNavigate();
    const [name, setName] = useState("")
    const [email, setEmail] = useState("")
    const [password, setPassword] = useState("")

    const postData=()=>{
       if(!/^(([^<>()\[\]\\.,;:\s@"]+(\.[^<>()\[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/.test(email)){
             M.toast({html: "Invalid email" ,classes:"#f44336 red"})
             return 
        }
      fetch("http://localhost:5000/signup",{
        method:"post",
        headers:{
          "Content-Type":"application/json"
        },
        body:JSON.stringify({
          name,
          password,
          email
        })
      }).then(res=>res.json())
      .then(data=>{
        console.log(data);
       if(data.error){
        M.toast({html: data.error ,classes:"#f44336 red"})
       }else{
        M.toast({html:data.message,classes:"#43a047 green darken-1"})
        history('/login')
       }
      }).catch(err=>{
        console.log(err);
      })
    }
   
  return (
    <div className='card-holder'>
    <div className="card ">
    <p className="brand-logo">Instagram</p>
    <input type="text" 
    placeholder='Name' 
    value={name} 
    onChange={(e)=>setName(e.target.value)}
    />
     <input type="text" placeholder='Email'value={email} onChange={(e)=>setEmail(e.target.value)}/>
     <input type="password" placeholder='Password'value={password} onChange={(e)=>setPassword(e.target.value)} />
  
     <button onClick={()=>postData()}>Signup</button>
     <p>
        <Link to="/login">Already have an account?</Link>
     </p>
</div>
</div>
  )
}

export default Signup