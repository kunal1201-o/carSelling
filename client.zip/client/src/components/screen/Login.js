import React, { useState } from 'react'
import { Link, useNavigate } from 'react-router-dom'
import M from 'materialize-css'
const Login = () => {
  const history = useNavigate();

  const [email, setEmail] = useState("")
  const [password, setPassword] = useState("")

  const postLog = () => {
    fetch("http://localhost:5000/signin", {
      method: "post",
      headers: {
        "Content-Type": "application/json"
      },
      body: JSON.stringify({

        password,
        email
      })
    }).then(res => res.json())
      .then(data => {
        if (data.error) {
          M.toast({ html: data.error, classes: "#f44336 red" })
        } else {
          M.toast({ html: "Login successfully", classes: "#43a047 green darken-1" })
          console.log(data);
          localStorage.setItem('user', data.user);
          localStorage.setItem('token', data.token);


          history('/');
        }
      })
  }
  return (
    <div className='card-holder'>

      <div class="card ">
        <p className="brand-logo">Instagram</p>
        <input type="text"
          placeholder='Email'
          value={email}
          onChange={(e) => setEmail(e.target.value)}
        />
        <input type="password"
          placeholder='Password'
          value={password}
          onChange={(e) => setPassword(e.target.value)}
        />
        <button onClick={() => postLog()}>Login</button>
        <p>
          <Link to="/signup">Don't have an account?</Link>
        </p>
      </div>
    </div>
  )
}

export default Login